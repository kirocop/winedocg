import UIKit
import PlaygroundSupport

public let master = WineMasterViewController()
public let nav = UINavigationController(rootViewController: master)

