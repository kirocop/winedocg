import UIKit
import PlaygroundSupport

public class WineMasterViewController: UITableViewController {
    
    public override func viewDidLoad() {
        title = "The DOCG wines in Italy 🍷"
    }
    
    //This is an array with all italian's regions.
    public var regions = ["Abruzzo", "Basilicata", "Campania", "Emilia Romagna", "Friuli Venezia-Giulia", "Lazio", "Lombardia", "Marche", "Piemonte", "Puglia", "Sardegna", "Sicilia", "Toscana", "Umbria", "Veneto"]
    
    public override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return regions.count
    }
    
    
    
    //the cells in the table view
    public override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // attempt to dequeue a cell
        var cell: UITableViewCell!
        cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        
        if cell == nil {
            // none to dequeue – make a new one
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "Cell")
            cell?.accessoryType = .disclosureIndicator
        }
        
        // configure cell
        
        let region = regions[indexPath.row]
        cell.detailTextLabel?.text = "List of DOCG wine in \(region)"
        cell.textLabel?.text = "\(region)"
        
        return cell
    }
    
   public override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let text = tableView.cellForRow(at: indexPath)?.textLabel?.text else { return }
        
        
        
        let detail = WineDetailViewController()
        detail.message = text
        navigationController?.pushViewController(detail, animated: true)
    }
    
    
}

//Class for the content in the single cells
public class WineDetailViewController: UITableViewController {
    
    var message = ""
    var regionWines:[String] = []
    

    //Dictionary with all the DOCG wines for each regions
    var wines = [
        "Abruzzo" : ["Montepulciano d'Abruzzo Colline Teramane"],
        "Basilicata": ["Aglianico del Vulture Superiore"],
        "Campania": ["Fiano di Avellino","Aglianico del Taburno","Taurasi", "Greco di Tufo"],
        "Emilia Romagna": ["Colli Bolognesi Classico Pignoletto", "Romagna Albana"],
        "Friuli Venezia-Giulia" : ["Colli Orientali del Friuli Picolit", "Lison", "Ramandolo", "Rosazzo"],
        "Lazio": ["Cannellino di Frascati", "Cesanese del Piglio", "Frascati Superiore"],
        "Lombardia" : ["Franciacorta", "Oltrepò Pavese metodo classico", "Scanzo", "Sforzato di Valtellina", "Valtellina Superiore"],
        "Marche" : ["Castelli di Jesi Verdicchio Riserva", "Conero", "Offida", "Verdicchio di Matelica", "Vernaccia di Serrapetrona"],
        "Piemonte" : ["Alta Langa", "Barbarescho d'Asti", "Asti", "Barbera del Monferrato Superiore", "Barolo", "Brachetto d'Acqui", "Dolcetto di Diano d'Alba", "Dolcetto di Ovada superiore", "Dogliani", "Erbaluce di Caluso", "Gattinara", "Gavi", "Ghemme", "Nizza", "Roero", "Ruchè di Castagnole Monferrato"],
        "Puglia" : ["Castel del Monte Bombino Nero", "Castel del Monte Rosso Riserva", "Castel del Monte Nero di Troia riserva", "Primitivo di Manduria dolce naturale"],
        "Sardegna" : ["Vermentino di Gallura"],
        "Sicilia" : ["Cerasuolo di Vittoria"],
        "Toscana" : ["Brunello di Montalcini", "Carmignano", "Chianti", "Chianti Classico", "Elba Aleatico Passito", "Montecucco Sangiovese", "Morellino di Scansano", "Suvereto", "Val di Cornia Rosso", "Vernaccia di San Gimignano", "Vino Nobile di Montepulciano"],
        "Umbria" : ["Montefalco Sangrantino", "Torgiano Rosso Riserva"],
        "Veneto" : ["Amarone della Valpolicella", "Asolo - Prosecco", "Bagnoli Friularo", "Bardolino Superiore", "Colli di Cornegliano", "Colli Euganei Fior d'Arancio", "Conegliano Valdobbiadene - Prosecco", "Lison", "Montello Rosso", "Piave Malanotte", "Recioto della Valpolicella", "Recioto di Gambellara", "Recioto di Soave", "Soave Superiore"],
        ]
    
    public override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.regionWines = wines[message]!
    }
    
    public override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (wines[message]?.count)!
    }
    
    //the cells in the table view
    public override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // attempt to dequeue a cell
        var cell: UITableViewCell!
        cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        
        if cell == nil {
            // none to dequeue – make a new one
            
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "Cell")
            cell.textLabel?.text = "\(regionWines[indexPath.row])"
            
            //Animation Cell
            
            cell.layer.transform = CATransform3DMakeScale(0.1, 0.1, 1)
            UIView.animate(withDuration: 0.8, animations: {
                cell.layer.transform = CATransform3DMakeScale(1.05, 1.05, 1)
            },completion: { finished in
                UIView.animate(withDuration: 0.6, animations: {
                    cell.layer.transform = CATransform3DMakeScale(1, 1, 1)
                })
            })
            
        }
        
        return cell
        
        
    }
    
}
